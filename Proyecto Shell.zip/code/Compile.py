import os
os.system("gcc Shell.c -o ../.out/Shell")
os.system("./../.out/Shell")
